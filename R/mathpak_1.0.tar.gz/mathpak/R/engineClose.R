engineClose <-
function (handle) 
{
    mpskip[handle] <<- 0
    mpmode[handle] <<- "w"
}
