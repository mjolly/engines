mpClose <-
function (handle) 
{
    engineClose(handle)
}
