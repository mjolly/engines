mpWrite <-
function (handle, value, mode) 
{
    engineWrite(handle, value, mode)
}
