mpOpen <-
function (handle, mode) 
{
    engineOpen(handle, mode)
}
