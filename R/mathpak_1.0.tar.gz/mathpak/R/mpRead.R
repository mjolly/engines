mpRead <-
function (handle, records = 0) 
{
    engineRead(handle, records)
}
